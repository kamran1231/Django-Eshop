
from store.views.login import Login,logout
from store.views.signup import Signup
from store.views.home import Index
from store.views.cart import Cart
from store.views.checkout import CheckOut
from store.views.orders import Orders
